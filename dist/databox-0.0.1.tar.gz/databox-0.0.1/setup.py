from setuptools import setup, find_packages

setup(
    name = "databox",
    version = "0.0.1",
    packages=['databox',],
)

  # packages = find_packages()